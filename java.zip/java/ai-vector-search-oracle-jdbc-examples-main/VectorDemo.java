import oracle.jdbc.OracleType;
import java.io.File;
import java.sql.Connection; import java.sql.DriverManager; import java.sql.PreparedStatement; import java.sql.ResultSet;
import java.sql.SQLException; import java.sql.Statement;
import java.util.Arrays;
import java.util.Optional;
/**
* This is a basic demo using Oracle JDBC with the VECTOR data type.
* By default, JDBC connects to the "test" alias of $TNS_ADMIN/tnsnames.ora. * You can supply an alias other than "test", as an optional command-line argument.
* You must set any other connection properties, including the user name and the password,
* in the $TNS_ADMIN/ojdbc.properties file.
*/
public class VectorDemo {
    public static void main(String[] args) throws SQLException {
        String dbName = args.length == 0 ? "test" : args[0];
        System.out.printf(
            "Connecting to \"%s\"%s%n",
                dbName, 
                Optional.ofNullable(System.getenv("TNS_ADMIN"))
                .map(tnsAdmin -> " in " + tnsAdmin + File.separator +   
            "tnsnames.ora")
                    .orElse(" (Environment variable \"TNS_ADMIN\" is not set)"));
        try (
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@" + dbName); 
                Statement statement = connection.createStatement();) {
                    String createTableSql =
                        "CREATE TABLE vector_demo (\n" 
                        + " id NUMBER PRIMARY KEY,\n" 
                        + " value VECTOR(3, FLOAT64))";
                    System.out.println("\n" + createTableSql); statement.execute(createTableSql);
                    try {
                        String insertSql = "INSERT INTO vector_demo (id, value) VALUES (?, ?)";
                        try (PreparedStatement insertStatement = connection.prepareStatement(insertSql)) 
                        {  
                            double[] vector = {1.1, 2.2, 3.3}; 
                            System.out.println("\n" + insertSql); 
                            System.out.println("Inserting vector: " + Arrays.toString(vector)); insertStatement.setInt(1, 0);
                                insertStatement.setObject(2, vector, OracleType.VECTOR);
                                insertStatement.executeUpdate(); 
                        }
                        String querySql = "SELECT id, value FROM vector_demo";
                        try (PreparedStatement queryStatement = connection.prepareStatement(querySql))
                        {
                            System.out.println("\n" + querySql);
                            ResultSet resultSet = queryStatement.executeQuery(); resultSet.next();
                            double[] vector = resultSet.getObject(2, double[].class); System.out.println("Queried vector: " + Arrays.toString(vector));
                        }
                    }
                    finally {
                        statement.execute("DROP TABLE vector_demo");
                    }
                }
            }
} 