package oracle.jdbc.vector.examples.cohere;

import com.oracle.bmc.ClientConfiguration;
import com.oracle.bmc.ConfigFileReader;
import com.oracle.bmc.auth.AuthenticationDetailsProvider;
import com.oracle.bmc.auth.ConfigFileAuthenticationDetailsProvider;
import com.oracle.bmc.generativeaiinference.GenerativeAiInferenceClient;
import com.oracle.bmc.generativeaiinference.model.EmbedTextDetails;
import com.oracle.bmc.generativeaiinference.model.OnDemandServingMode;
import com.oracle.bmc.generativeaiinference.requests.EmbedTextRequest;
import com.oracle.bmc.generativeaiinference.responses.EmbedTextResponse;
import oracle.jdbc.vector.examples.Config;
import oracle.jdbc.vector.examples.Model;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A model which is accessed through the OCI Generative AI Service.
 */
public class CohereModel implements Model {
    private GenerativeAiInferenceClient generativeAiInferenceClient;

    public static final Model INSTANCE = new CohereModel();

    public CohereModel() {
        try {
            // Set up the client configuration
            ClientConfiguration clientConfiguration = ClientConfiguration.builder()
                    .readTimeoutMillis(240000)
                    .build();

            // Authenticate using the OCI configuration file
            AuthenticationDetailsProvider provider = new ConfigFileAuthenticationDetailsProvider(
                ConfigFileReader.parse(Config.get("OCI_CONFIG_LOCATION"), Config.get("OCI_CONFIG_PROFILE"))
            );

            generativeAiInferenceClient = new GenerativeAiInferenceClient(provider, clientConfiguration);
            generativeAiInferenceClient.setEndpoint(Config.get("OCI_ENDPOINT"));
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize the OCI Generative AI client", e);
        }
    }

    @Override
    public float[][] embed(String[] texts) {
        List<String> inputs = Arrays.asList(texts);
        float[][] embeddings = new float[inputs.size()][];

        // Process in batches of up to 96 items
        int batchSize = 96;
        for (int start = 0; start < inputs.size(); start += batchSize) {
            int end = Math.min(inputs.size(), start + batchSize);
            List<String> batchInputs = inputs.subList(start, end);
            
            EmbedTextDetails embedTextDetails = EmbedTextDetails.builder()
                    .servingMode(OnDemandServingMode.builder().modelId("cohere.embed-english-v3.0").build())
                    .compartmentId(Config.get("OCI_COMPARTMENT_ID"))
                    .inputs(batchInputs)
                    .build();

            EmbedTextRequest request = EmbedTextRequest.builder()
                    .embedTextDetails(embedTextDetails)
                    .build();

            EmbedTextResponse response = generativeAiInferenceClient.embedText(request);
            float[][] batchEmbeddings = parseResponse(response);
            
            // Combine batch embeddings into the main array
            System.arraycopy(batchEmbeddings, 0, embeddings, start, batchEmbeddings.length);
        }

        return embeddings;
    }

    private float[][] parseResponse(EmbedTextResponse response) {
        List<List<Float>> embeddingsList = response.getEmbedTextResult().getEmbeddings();
        float[][] embeddings = new float[embeddingsList.size()][];
        for (int i = 0; i < embeddingsList.size(); i++) {
            List<Float> embeddingList = embeddingsList.get(i);
            embeddings[i] = new float[embeddingList.size()];

            for (int j = 0; j < embeddingList.size(); j++) {
               embeddings[i][j] = embeddingList.get(j);
            }
          }
        // Placeholder for the response parsing logic
        // This should convert the response to the required float[][] format
        // Assume response parsing is implemented correctly here
        return embeddings;
    }
}
